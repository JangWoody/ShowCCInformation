package view;

import java.awt.FlowLayout;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class ConfigInfoPanel extends JPanel {
	private JLabel hostLabel2;
	private JLabel portLabel2;
	private JLabel userIDLabel2;
	private JLabel userPWLabel2;

	public ConfigInfoPanel() {
		loadConfig();

		JPanel hostPanel = new JPanel();
		hostPanel.setLayout(new FlowLayout(FlowLayout.LEADING));
		JLabel hostLabel1 = new JLabel("Host : ");
		hostLabel1.setFont(MainView.font13);
		hostLabel2 = new JLabel(MainView.host);
		hostLabel2.setFont(MainView.font13);
		hostPanel.add(hostLabel1);
		hostPanel.add(hostLabel2);
		add(hostPanel);

		JPanel portPanel = new JPanel();
		portPanel.setLayout(new FlowLayout(FlowLayout.LEADING));
		JLabel portLabel1 = new JLabel("Port : ");
		portLabel1.setFont(MainView.font13);
		portLabel2 = new JLabel(MainView.port);
		portLabel2.setFont(MainView.font13);
		portPanel.add(portLabel1);
		portPanel.add(portLabel2);
		add(portPanel);

		JPanel userIDPanel = new JPanel();
		userIDPanel.setLayout(new FlowLayout(FlowLayout.LEADING));
		JLabel userIDLabel1 = new JLabel("ID : ");
		userIDLabel1.setFont(MainView.font13);
		userIDLabel2 = new JLabel(MainView.userID);
		userIDLabel2.setFont(MainView.font13);
		userIDPanel.add(userIDLabel1);
		userIDPanel.add(userIDLabel2);
		add(userIDPanel);

		JPanel userPWPanel = new JPanel();
		userPWPanel.setLayout(new FlowLayout(FlowLayout.LEADING));
		JLabel userPWLabel1 = new JLabel("PW : ");
		userPWLabel1.setFont(MainView.font13);
		userPWLabel2 = new JLabel(MainView.userPW);
		userPWLabel2.setFont(MainView.font13);
		userPWPanel.add(userPWLabel1);
		userPWPanel.add(userPWLabel2);
		add(userPWPanel);
	}

	public void loadConfig() {
		ArrayList<String> configArray = FileDAO.getConfig();
		if (configArray.size() < 2) {
			JOptionPane.showMessageDialog(this, "properties ���� Ȯ��", "conn ���� Ȯ�� �Ұ�", JOptionPane.ERROR_MESSAGE);
			return;
		}
		MainView.host = configArray.get(0);
		MainView.port = configArray.get(1);
		MainView.userID = configArray.get(2);
		MainView.userPW = configArray.get(3);
	}

	public void setConfigLabel() {
		loadConfig();
		hostLabel2.setText(MainView.host);
		portLabel2.setText(MainView.port);
		userIDLabel2.setText(MainView.userID);
		userPWLabel2.setText(MainView.userPW);
		this.revalidate();
		this.repaint();
	}

}