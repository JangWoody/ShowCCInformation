package view;

import java.io.IOException;
import java.io.StringReader;
import java.util.Base64;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class XMLBodyParser {
	private static Document document;

	public static String ccName = "";
	public static String ccType = "";
	public static String adapterStatus = "";
	public static String autoCommit = "";
	public static String batchMode = "";
	public static String connURL = "";
	public static String soapAction = "";
	public static String connID = "";
	public static String connPassword = "";
	public static String ftpPath = "";
	public static String ftpFileName = "";
	public static String pollingTime = "";

	public static void parseXML(String xmlBody) {
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xmlBody));
			document = db.parse(is);
			document.getDocumentElement().normalize();

			getCCName("p1:idInfo"); // ccName
			getCCType("p1:generic"); // ccType
			getNodeItem("Attribute"); // else

			new ResultDialog();
		} catch (ParserConfigurationException | SAXException | IOException e) {
			e.printStackTrace();
		}

	}

	private static void getCCName(String nodeName) {
		NodeList nList = document.getElementsByTagName(nodeName);

		for (int i = 0; i < nList.getLength(); i++) {
			Node nNode = nList.item(i);
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;
				String element1 = eElement.getElementsByTagName("p1:elem").item(1).getTextContent();
				String element2 = eElement.getElementsByTagName("p1:elem").item(2).getTextContent();
				ccName = element1 + " | " + element2;
			}
		}
	}

	private static void getCCType(String nodeName) {
		NodeList nList = document.getElementsByTagName(nodeName);

		for (int i = 0; i < nList.getLength(); i++) {
			Node nNode = nList.item(i);
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				if (ccName.contains("JAVA")) {
					ccType = "JAVA PROXY";
					return;
				}
				Element eElement = (Element) nNode;
				String element1 = eElement.getElementsByTagName("p1:elem").item(0).getTextContent();
				ccType = element1;
			}
		}
	}

	private static void getNodeItem(String nodeName) {
		NodeList nList = document.getElementsByTagName(nodeName);

		for (int i = 0; i < nList.getLength(); i++) {
			Node nNode = nList.item(i);
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;
				String element = eElement.getElementsByTagName("Name").item(0).getTextContent();
				switch (element) {
				case "adapterStatus":
					adapterStatus = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent();
					break;
				case "autoCommit":
					autoCommit = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent().equals("0")
							? "False"
							: "True";
					break;
				case "batchMode":
					batchMode = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent().equals("0")
							? "False"
							: "True";
					break;
				case "connectionURL":
					connURL = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent();
					break;
				case "XMBWS.TargetURL":
					connURL = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent();
					break;
				case "XMBWS.DefaultSOAPAction":
					soapAction = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent();
					break;
				case "dbuser":
					connID = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent();
					break;
				case "dbpassword":
					connPassword = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent();
					if (!connPassword.equals("****")) {
						connPassword = decryptPassword(connPassword);
					} else {
						connPassword = "��ȣȭ �Ұ�";
					}
					break;
				case "logonUser":
					connID = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent();
					break;
				case "logonPassword":
					connPassword = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent();
					if (!connPassword.equals("****")) {
						connPassword = decryptPassword(connPassword);
					} else {
						connPassword = "��ȣȭ �Ұ�";
					}
					break;
				case "URLPattern":
					connURL = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent();
					break;
				case "HttpUser":
					connID = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent();
					break;
				case "HttpPassword":
					connPassword = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent();
					if (!connPassword.equals("****")) {
						connPassword = decryptPassword(connPassword);
					} else {
						connPassword = "��ȣȭ �Ұ�";
					}
					break;
				case "advancedFileSources":
					try {
						ftpPath = ((Element) nNode).getElementsByTagName("Fieldvalue").item(0).getTextContent();
						ftpFileName = ((Element) nNode).getElementsByTagName("Fieldvalue").item(2).getTextContent();
					} catch (NullPointerException e) {
					}
					break;
				case "fileDirectory":
					if (((Element) nNode).getElementsByTagName("Value").item(0).getTextContent().length() > 0) {
						ftpPath = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent();
					}
					break;
				case "regFileName":
					if (((Element) nNode).getElementsByTagName("Value").item(0).getTextContent().length() > 0) {
						ftpFileName = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent();
					}
					break;
				case "filePath":
					if (((Element) nNode).getElementsByTagName("Value").item(0).getTextContent().length() > 0) {
						ftpPath = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent();
					}
					break;
				case "serverhost":
					connURL = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent();
					break;
				case "serverport":
					connURL += ":" + ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent();
					break;
				case "userName":
					connID = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent();
					break;
				case "password":
					connPassword = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent();
					if (!connPassword.equals("****")) {
						connPassword = decryptPassword(connPassword);
					} else {
						connPassword = "��ȣȭ �Ұ�";
					}
					break;
				case "interv.poll":
					pollingTime = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent();
					break;
				case "pollInterval":
					pollingTime = ((Element) nNode).getElementsByTagName("Value").item(0).getTextContent();
					break;
				default:
					break;
				}
			}
		}
	}

	private static String decryptPassword(String encryptedPW) {
		byte[] aByteArray = Base64.getDecoder().decode(encryptedPW);
		int len = aByteArray.length;
		byte[] result = new byte[len - 1];
		for (int i = 1; i < len; i++) {
			result[(len - 1 - i)] = ((byte) (aByteArray[i] ^ 0x74));
		}
		String decryptedPW = new String(result);

		return decryptedPW;
	}

	public static void initField() {
		ccName = "";
		ccType = "";
		adapterStatus = "";
		autoCommit = "";
		batchMode = "";
		connURL = "";
		soapAction = "";
		connID = "";
		connPassword = "";
		ftpPath = "";
		ftpFileName = "";
	}

}