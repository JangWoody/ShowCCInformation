package view;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.BevelBorder;

public class CCListDialog extends JDialog {
	public CCListDialog(ArrayList<String> responseList) {
		setModal(true);

		JPanel ccListPanel = new JPanel();
		ccListPanel.setLayout(new BoxLayout(ccListPanel, BoxLayout.Y_AXIS));

		JScrollPane scrlPnl = new JScrollPane(ccListPanel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrlPnl.setPreferredSize(new Dimension(600, 400));

		for (String str : responseList) {
			JPanel strPanel = new JPanel();

			JLabel strLabel = new JLabel(str);
			strLabel.setFont(new Font("����", Font.PLAIN, 15));
			strLabel.setPreferredSize(new Dimension(550, 35));
			strLabel.setBorder(new BevelBorder(BevelBorder.RAISED));

			strLabel.addMouseListener(new LabelClickListener());

			strPanel.add(strLabel);
			ccListPanel.add(strPanel);
		}

		add(scrlPnl);
		showGUI();
	}

	private void showGUI() {
// pack();
		setSize(600, 400);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setVisible(true);
	}

	private class LabelClickListener extends MouseAdapter {
		@Override
		public void mouseClicked(MouseEvent e) {
			String clickedLabel = ((JLabel) e.getSource()).getText();
			String bsName = clickedLabel.substring(0, clickedLabel.indexOf("|"));
			String ccName = clickedLabel.substring(clickedLabel.indexOf("|") + 1);

			String responseXML = HTTPSender.getResponse(bsName, ccName);
			if (responseXML == null || responseXML.length() == 0) {
				JOptionPane.showMessageDialog(Main.mainView, "BS, CC ��Ȯ��", "��ȸ �Ұ�", JOptionPane.ERROR_MESSAGE);
				return;
			}
			XMLBodyParser.parseXML(responseXML);

			XMLBodyParser.initField();
		}

	}
}