package view;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class FileDAO {
	private FileDAO() {
	}

	public static ArrayList<String> getConfig() {
		ArrayList<String> configArray = new ArrayList<String>();

		String filePath = System.getProperty("user.dir") + "\\host.properties";
		File f = new File(filePath);

		if (!f.exists()) {
			try {
				f.createNewFile();
				FileOutputStream fos = new FileOutputStream(f);
				OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
				osw.write("host=\r\nport=\r\nuser=\r\npassword=");
				osw.flush();
				osw.close();
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		FileInputStream fis = null;
		try {
			int data = 0;
			fis = new FileInputStream(f);
			StringBuilder sb = new StringBuilder();
			Boolean check = false;
			while ((data = fis.read()) != -1) {
				if ((char) data == '#') {
					check = true;
					continue;
				}
				if (data == '\r') {
					if (check || sb.toString().length() < 5) {
						sb = null;
						sb = new StringBuilder();
						check = false;
						continue;
					}
					String inputString = sb.toString();
					configArray.add(inputString.substring(inputString.indexOf('=') + 1));
					sb = null;
					sb = new StringBuilder();
					continue;
				}
				sb.append((char) data);
			}
			String inputString = sb.toString();
			configArray.add(inputString.substring(inputString.indexOf('=') + 1));
		} catch (IOException e) {
			configArray.add(e.toString().substring(0, (e.toString().length() > 15) ? 10 : 3));
		} finally {
			try {
				if (fis != null)
					fis.close();
			} catch (IOException e) {
			}
		}
		return configArray;
	}
}
