package view;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.stream.Collectors;

public class HTTPSender {

	public static String getResponse(String bs, String cc) {
		String httpURL = makeHttpURL(bs, cc);
		String userAuth = encodingAuth();

		String resultString = "";

		try {
			URL url = new URL(httpURL);

			URLConnection connection = url.openConnection();

			connection.setRequestProperty("Accept-Encoding", "UTF-8");
			connection.addRequestProperty("Authorization", userAuth);

			InputStream response = null;
			response = connection.getInputStream();
			if (response == null) {
				return null;
			}

			resultString = new BufferedReader(new InputStreamReader(response, StandardCharsets.UTF_8)).lines()
					.collect(Collectors.joining("\n"));
		} catch (IOException e1) {
		}
		return resultString;
	}

	private static String makeHttpURL(String bs, String cc) {
		bs = bs.trim();
		cc = cc.trim();

		StringBuffer urlBuffer = new StringBuffer();
		urlBuffer.append("http://");
		urlBuffer.append(MainView.host);
		urlBuffer.append(":");
		urlBuffer.append(MainView.port);
		urlBuffer.append("/dir/read/ext?method=PLAIN&TYPE=Channel&KEY=%7C");
		urlBuffer.append(bs);
		urlBuffer.append("%7C");
		urlBuffer.append(cc);
		urlBuffer.append("&VC=DIR&UC=true&release=7.0");

		return urlBuffer.toString();
	}

	private static String encodingAuth() {
		String userIDPW = MainView.userID;
		userIDPW += ":";
		userIDPW += MainView.userPW;

		String encodedAuth = "Basic ";
		encodedAuth += Base64.getEncoder().encodeToString(userIDPW.getBytes());
		return encodedAuth;
	}

}