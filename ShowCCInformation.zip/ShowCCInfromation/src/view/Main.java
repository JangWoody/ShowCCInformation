package view;

public class Main {
	public static MainView mainView;

	public static void main(String[] args) {
		MainView mainView = new MainView();
	}

}
