package view;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.BoxLayout;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class ResultDialog extends JDialog {
	public ResultDialog() {
		setModal(true);

		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

		JPanel subjectPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

		JLabel nameLabel = new JLabel(XMLBodyParser.ccName);
		nameLabel.setFont(new Font("����", Font.BOLD, 17));
		subjectPanel.add(nameLabel);

		JPanel textAreaPanel = new JPanel();
		textAreaPanel.setLayout(new BoxLayout(textAreaPanel, BoxLayout.Y_AXIS));

		JScrollPane scrlPnl = new JScrollPane(textAreaPanel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrlPnl.setPreferredSize(new Dimension(500, 300));

		JTextArea textArea = new JTextArea();
		textArea.setFont(new Font("����", Font.PLAIN, 15));
		textArea.setEditable(false);
		textArea.setLineWrap(true);
		textAreaPanel.add(textArea);

		StringBuilder sb = new StringBuilder();
		sb.append("Adapter Type : " + XMLBodyParser.ccType + "\n");
		if (XMLBodyParser.ccName.contains("Sender")) {
			sb.append("Polling Interval : " + XMLBodyParser.pollingTime + "\n");
		}
		sb.append("URL : " + XMLBodyParser.connURL + "\n");
		if (XMLBodyParser.ccType.equals("SOAP")) {
			XMLBodyParser.soapAction = XMLBodyParser.soapAction.length() > 0 ? XMLBodyParser.soapAction : "NONE";
			sb.append("SOAP Action : " + XMLBodyParser.soapAction + "\n");
		}
		if (XMLBodyParser.ccType.contains("FTP")) {
			sb.append("FTP Path : " + XMLBodyParser.ftpPath + "\n");
			sb.append("FTP File Name : " + XMLBodyParser.ftpFileName + "\n");
		}
		sb.append("Conn ID : " + XMLBodyParser.connID + "\n");
		sb.append("Conn PW : " + XMLBodyParser.connPassword + "\n");
		if (XMLBodyParser.ccType.startsWith("JDBC")) {
			sb.append("Auto Commit : " + XMLBodyParser.autoCommit + "\n");
			sb.append("Batch Mode : " + XMLBodyParser.batchMode + "\n");
		}
		sb.append("Adapter Status : " + XMLBodyParser.adapterStatus + "\n");
		textArea.setText(sb.toString());

		mainPanel.add(subjectPanel);
		mainPanel.add(scrlPnl);
		add(mainPanel);
		showGUI();
	}

	private void showGUI() {
// pack();
		setSize(500, 300);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setVisible(true);
	}
}