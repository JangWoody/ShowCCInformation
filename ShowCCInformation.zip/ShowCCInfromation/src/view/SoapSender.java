package view;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collections;

import org.apache.axis.types.Token;

import com.sap.xi.BASIS.CommunicationChannelID;
import com.sap.xi.BASIS.CommunicationChannelIn;
import com.sap.xi.BASIS.CommunicationChannelInBindingStub;
import com.sap.xi.BASIS.CommunicationChannelInProxy;
import com.sap.xi.BASIS.CommunicationChannelQueryIn;
import com.sap.xi.BASIS.CommunicationChannelQueryOut;

public class SoapSender {
	private ArrayList<String> response = null;

	public SoapSender(String bsName) {
		this.response = callSoapService(bsName);
	}

	private ArrayList<String> callSoapService(String bsName) {
		CommunicationChannelQueryIn ccQueryRequest = new CommunicationChannelQueryIn();
		CommunicationChannelInProxy proxy = new CommunicationChannelInProxy();
		if (bsName.length() > 0) {
			CommunicationChannelID ccQueryID = new CommunicationChannelID();
			ccQueryID.setComponentID(new Token(bsName));
			ccQueryID.setChannelID(new Token(""));
			ccQueryID.setPartyID(new Token(""));
			ccQueryRequest.setCommunicationChannelID(ccQueryID);
		}
		try {
			String soapURL = "http://";
			soapURL += MainView.host + ":" + MainView.port
					+ "/CommunicationChannelInService/CommunicationChannelInImplBean";
			proxy.setEndpoint(soapURL);

			CommunicationChannelIn ccIn = proxy.getCommunicationChannelIn();
			((CommunicationChannelInBindingStub) ccIn).setUsername(MainView.userID);
			((CommunicationChannelInBindingStub) ccIn).setPassword(MainView.userPW);

			CommunicationChannelQueryOut ccQueryResponse = proxy.query(ccQueryRequest);

			return parseResponse(ccQueryResponse);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return null;
	}

	private ArrayList<String> parseResponse(CommunicationChannelQueryOut response) {
		ArrayList<String> result = new ArrayList<String>();

		CommunicationChannelID[] responseList = response.getCommunicationChannelID();
		for (CommunicationChannelID id : responseList) {
			String ccName = id.getChannelID().toString();
			String ccBSName = id.getComponentID().toString();
			result.add(ccBSName + "|" + ccName);
		}

		Collections.sort(result);

		return result;
	}

	public ArrayList<String> getResponse() {
		return response;
	}
}
