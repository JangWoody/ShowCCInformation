package view;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class InputPanel extends JPanel {
	private JTextField bsTF;
	private JTextField ccTF;

	public InputPanel() {
		JPanel bsPanel = new JPanel();
		bsPanel.setLayout(new FlowLayout(FlowLayout.LEADING));
		JLabel bsLabel = new JLabel("Buisiness System : ");
		bsLabel.setFont(MainView.font13);
		bsTF = new JTextField(7);
		bsPanel.add(bsLabel);
		bsPanel.add(bsTF);
		add(bsPanel);

		JPanel ccPanel = new JPanel();
		ccPanel.setLayout(new FlowLayout(FlowLayout.LEADING));
		JLabel ccLabel = new JLabel("CC Name : ");
		ccLabel.setFont(MainView.font13);
		ccTF = new JTextField(17);
		ccPanel.add(ccLabel);
		ccPanel.add(ccTF);
		add(ccPanel);

		JPanel btnPanel = new JPanel();
		btnPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
		JButton searchButton = new JButton("��ȸ");
		searchButton.setFont(MainView.font13);
		searchButton.addActionListener(new SearchButtonActionListener());
		btnPanel.add(searchButton);
		add(btnPanel);
	}

	private class SearchButtonActionListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			if (ccTF.getText().length() > 0) { // CC ���̷�Ʈ ��ȸ
				String responseXML = HTTPSender.getResponse(bsTF.getText(), ccTF.getText());
				if (responseXML == null || responseXML.length() == 0) {
					JOptionPane.showMessageDialog(Main.mainView, "BS, CC ��Ȯ��", "��ȸ �Ұ�", JOptionPane.ERROR_MESSAGE);
					return;
				}
				XMLBodyParser.parseXML(responseXML);

				XMLBodyParser.initField();
				return;
			}

//BS �̿� ��ȸ
			ArrayList<String> responseList = new SoapSender(bsTF.getText()).getResponse();
			new CCListDialog(responseList);
		}
	}
}
