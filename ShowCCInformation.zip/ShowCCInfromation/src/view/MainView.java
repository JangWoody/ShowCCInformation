package view;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

public class MainView extends JFrame {
	public static final Font font13 = new Font("����", Font.PLAIN, 13);
	public static String host = "NONE";
	public static String port = "NONE";
	public static String userID = "NONE";
	public static String userPW = "NONE";

	public MainView() {
		ConfigInfoPanel configPanel = new ConfigInfoPanel();
		configPanel.setLayout(new BoxLayout(configPanel, BoxLayout.Y_AXIS));
		InputPanel inputPanel = new InputPanel();
		inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.Y_AXIS));

		JMenuBar mb = new JMenuBar();
		JMenu screenMenu = new JMenu("����");
		JMenuItem reloadRule = new JMenuItem("conn load");

		reloadRule.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				configPanel.setConfigLabel();
			}
		});

		screenMenu.add(reloadRule);
		mb.add(screenMenu);
		add(mb, "North");

		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

		mainPanel.add(configPanel);
		mainPanel.add(inputPanel);

		add(mainPanel, BorderLayout.CENTER);
		showGUI();
	}

	private void showGUI() {
		setTitle("ä������ ��ȸ");
		pack();
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
}