/**
 * CommunicationChannelInServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.sap.xi.BASIS;

public class CommunicationChannelInServiceLocator extends org.apache.axis.client.Service implements com.sap.xi.BASIS.CommunicationChannelInService {

    public CommunicationChannelInServiceLocator() {
    }


    public CommunicationChannelInServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public CommunicationChannelInServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for CommunicationChannelInPort
    private java.lang.String CommunicationChannelInPort_address = "http://hyspoap1dev.skhynix.com:50000/CommunicationChannelInService/CommunicationChannelInImplBean";

    public java.lang.String getCommunicationChannelInPortAddress() {
        return CommunicationChannelInPort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String CommunicationChannelInPortWSDDServiceName = "CommunicationChannelInPort";

    public java.lang.String getCommunicationChannelInPortWSDDServiceName() {
        return CommunicationChannelInPortWSDDServiceName;
    }

    public void setCommunicationChannelInPortWSDDServiceName(java.lang.String name) {
        CommunicationChannelInPortWSDDServiceName = name;
    }

    public com.sap.xi.BASIS.CommunicationChannelIn getCommunicationChannelInPort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(CommunicationChannelInPort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getCommunicationChannelInPort(endpoint);
    }

    public com.sap.xi.BASIS.CommunicationChannelIn getCommunicationChannelInPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.sap.xi.BASIS.CommunicationChannelInBindingStub _stub = new com.sap.xi.BASIS.CommunicationChannelInBindingStub(portAddress, this);
            _stub.setPortName(getCommunicationChannelInPortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setCommunicationChannelInPortEndpointAddress(java.lang.String address) {
        CommunicationChannelInPort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.sap.xi.BASIS.CommunicationChannelIn.class.isAssignableFrom(serviceEndpointInterface)) {
                com.sap.xi.BASIS.CommunicationChannelInBindingStub _stub = new com.sap.xi.BASIS.CommunicationChannelInBindingStub(new java.net.URL(CommunicationChannelInPort_address), this);
                _stub.setPortName(getCommunicationChannelInPortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("CommunicationChannelInPort".equals(inputPortName)) {
            return getCommunicationChannelInPort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://sap.com/xi/BASIS", "CommunicationChannelInService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://sap.com/xi/BASIS", "CommunicationChannelInPort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("CommunicationChannelInPort".equals(portName)) {
            setCommunicationChannelInPortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
