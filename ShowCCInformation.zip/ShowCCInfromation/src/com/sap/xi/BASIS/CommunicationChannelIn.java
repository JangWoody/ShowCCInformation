/**
 * CommunicationChannelIn.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.sap.xi.BASIS;

public interface CommunicationChannelIn extends java.rmi.Remote {
    public com.sap.xi.BASIS.LogMessageCollection check(com.sap.xi.BASIS.CommunicationChannelID[] communicationChannelCheckRequest) throws java.rmi.RemoteException;
    public com.sap.xi.BASIS.LogMessageCollection revert(com.sap.xi.BASIS.CommunicationChannelID[] communicationChannelRevertRequest) throws java.rmi.RemoteException;
    public com.sap.xi.BASIS.CommunicationChannelQueryOut query(com.sap.xi.BASIS.CommunicationChannelQueryIn communicationChannelQueryRequest) throws java.rmi.RemoteException;
    public com.sap.xi.BASIS.ConfigurationObjectModifyOut create(com.sap.xi.BASIS.CommunicationChannelCreateChangeIn communicationChannelCreateRequest) throws java.rmi.RemoteException;
    public com.sap.xi.BASIS.ConfigurationObjectModifyOut change(com.sap.xi.BASIS.CommunicationChannelCreateChangeIn communicationChannelChangeRequest) throws java.rmi.RemoteException;
    public com.sap.xi.BASIS.CommunicationChannelOpenForEditOut openForEdit(com.sap.xi.BASIS.CommunicationChannelDeleteOpenForEditIn communicationChannelOpenForEditRequest) throws java.rmi.RemoteException;
    public com.sap.xi.BASIS.ConfigurationObjectModifyOut createFromTemplate(com.sap.xi.BASIS.CommunicationChannelCreateFromTemplateIn communicationChannelCreateFromTemplateRequest) throws java.rmi.RemoteException;
    public com.sap.xi.BASIS.CommunicationChannelReadOut read(com.sap.xi.BASIS.CommunicationChannelReadIn communicationChannelReadRequest) throws java.rmi.RemoteException;
    public com.sap.xi.BASIS.ConfigurationObjectModifyOut delete(com.sap.xi.BASIS.CommunicationChannelDeleteOpenForEditIn communicationChannelDeleteRequest) throws java.rmi.RemoteException;
}
