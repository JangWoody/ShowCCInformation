package com.sap.xi.BASIS;

public class CommunicationChannelInProxy implements com.sap.xi.BASIS.CommunicationChannelIn {
  private String _endpoint = null;
  private com.sap.xi.BASIS.CommunicationChannelIn communicationChannelIn = null;
  
  public CommunicationChannelInProxy() {
    _initCommunicationChannelInProxy();
  }
  
  public CommunicationChannelInProxy(String endpoint) {
    _endpoint = endpoint;
    _initCommunicationChannelInProxy();
  }
  
  private void _initCommunicationChannelInProxy() {
    try {
      communicationChannelIn = (new com.sap.xi.BASIS.CommunicationChannelInServiceLocator()).getCommunicationChannelInPort();
      if (communicationChannelIn != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)communicationChannelIn)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)communicationChannelIn)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (communicationChannelIn != null)
      ((javax.xml.rpc.Stub)communicationChannelIn)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.sap.xi.BASIS.CommunicationChannelIn getCommunicationChannelIn() {
    if (communicationChannelIn == null)
      _initCommunicationChannelInProxy();
    return communicationChannelIn;
  }
  
  public com.sap.xi.BASIS.LogMessageCollection check(com.sap.xi.BASIS.CommunicationChannelID[] communicationChannelCheckRequest) throws java.rmi.RemoteException{
    if (communicationChannelIn == null)
      _initCommunicationChannelInProxy();
    return communicationChannelIn.check(communicationChannelCheckRequest);
  }
  
  public com.sap.xi.BASIS.LogMessageCollection revert(com.sap.xi.BASIS.CommunicationChannelID[] communicationChannelRevertRequest) throws java.rmi.RemoteException{
    if (communicationChannelIn == null)
      _initCommunicationChannelInProxy();
    return communicationChannelIn.revert(communicationChannelRevertRequest);
  }
  
  public com.sap.xi.BASIS.CommunicationChannelQueryOut query(com.sap.xi.BASIS.CommunicationChannelQueryIn communicationChannelQueryRequest) throws java.rmi.RemoteException{
    if (communicationChannelIn == null)
      _initCommunicationChannelInProxy();
    return communicationChannelIn.query(communicationChannelQueryRequest);
  }
  
  public com.sap.xi.BASIS.ConfigurationObjectModifyOut create(com.sap.xi.BASIS.CommunicationChannelCreateChangeIn communicationChannelCreateRequest) throws java.rmi.RemoteException{
    if (communicationChannelIn == null)
      _initCommunicationChannelInProxy();
    return communicationChannelIn.create(communicationChannelCreateRequest);
  }
  
  public com.sap.xi.BASIS.ConfigurationObjectModifyOut change(com.sap.xi.BASIS.CommunicationChannelCreateChangeIn communicationChannelChangeRequest) throws java.rmi.RemoteException{
    if (communicationChannelIn == null)
      _initCommunicationChannelInProxy();
    return communicationChannelIn.change(communicationChannelChangeRequest);
  }
  
  public com.sap.xi.BASIS.CommunicationChannelOpenForEditOut openForEdit(com.sap.xi.BASIS.CommunicationChannelDeleteOpenForEditIn communicationChannelOpenForEditRequest) throws java.rmi.RemoteException{
    if (communicationChannelIn == null)
      _initCommunicationChannelInProxy();
    return communicationChannelIn.openForEdit(communicationChannelOpenForEditRequest);
  }
  
  public com.sap.xi.BASIS.ConfigurationObjectModifyOut createFromTemplate(com.sap.xi.BASIS.CommunicationChannelCreateFromTemplateIn communicationChannelCreateFromTemplateRequest) throws java.rmi.RemoteException{
    if (communicationChannelIn == null)
      _initCommunicationChannelInProxy();
    return communicationChannelIn.createFromTemplate(communicationChannelCreateFromTemplateRequest);
  }
  
  public com.sap.xi.BASIS.CommunicationChannelReadOut read(com.sap.xi.BASIS.CommunicationChannelReadIn communicationChannelReadRequest) throws java.rmi.RemoteException{
    if (communicationChannelIn == null)
      _initCommunicationChannelInProxy();
    return communicationChannelIn.read(communicationChannelReadRequest);
  }
  
  public com.sap.xi.BASIS.ConfigurationObjectModifyOut delete(com.sap.xi.BASIS.CommunicationChannelDeleteOpenForEditIn communicationChannelDeleteRequest) throws java.rmi.RemoteException{
    if (communicationChannelIn == null)
      _initCommunicationChannelInProxy();
    return communicationChannelIn.delete(communicationChannelDeleteRequest);
  }
  
  
}