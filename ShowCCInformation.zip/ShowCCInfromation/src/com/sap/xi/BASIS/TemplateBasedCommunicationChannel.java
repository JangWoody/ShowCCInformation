/**
 * TemplateBasedCommunicationChannel.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.sap.xi.BASIS;

public class TemplateBasedCommunicationChannel  implements java.io.Serializable {
    private org.apache.axis.types.Language masterLanguage;

    private com.sap.xi.BASIS.RestrictedObjectAdministrativeData administrativeData;

    private com.sap.xi.BASIS.Global.LONG_Description[] description;

    private com.sap.xi.BASIS.CommunicationChannelID communicationChannelID;

    private com.sap.xi.BASIS.DesignObjectID channelTemplate;

    private org.apache.axis.types.Token adapterEngineName;

    private com.sap.xi.BASIS.GenericProperty[] adapterSpecificAttribute;

    private com.sap.xi.BASIS.GenericPropertyTable[] adapterSpecificTableAttribute;

    private com.sap.xi.BASIS.ModuleProcess moduleProcess;

    private com.sap.xi.BASIS.ChannelAdditionalIdentifier senderIdentifier;

    private com.sap.xi.BASIS.ChannelAdditionalIdentifier receiverIdentifier;

    public TemplateBasedCommunicationChannel() {
    }

    public TemplateBasedCommunicationChannel(
           org.apache.axis.types.Language masterLanguage,
           com.sap.xi.BASIS.RestrictedObjectAdministrativeData administrativeData,
           com.sap.xi.BASIS.Global.LONG_Description[] description,
           com.sap.xi.BASIS.CommunicationChannelID communicationChannelID,
           com.sap.xi.BASIS.DesignObjectID channelTemplate,
           org.apache.axis.types.Token adapterEngineName,
           com.sap.xi.BASIS.GenericProperty[] adapterSpecificAttribute,
           com.sap.xi.BASIS.GenericPropertyTable[] adapterSpecificTableAttribute,
           com.sap.xi.BASIS.ModuleProcess moduleProcess,
           com.sap.xi.BASIS.ChannelAdditionalIdentifier senderIdentifier,
           com.sap.xi.BASIS.ChannelAdditionalIdentifier receiverIdentifier) {
           this.masterLanguage = masterLanguage;
           this.administrativeData = administrativeData;
           this.description = description;
           this.communicationChannelID = communicationChannelID;
           this.channelTemplate = channelTemplate;
           this.adapterEngineName = adapterEngineName;
           this.adapterSpecificAttribute = adapterSpecificAttribute;
           this.adapterSpecificTableAttribute = adapterSpecificTableAttribute;
           this.moduleProcess = moduleProcess;
           this.senderIdentifier = senderIdentifier;
           this.receiverIdentifier = receiverIdentifier;
    }


    /**
     * Gets the masterLanguage value for this TemplateBasedCommunicationChannel.
     * 
     * @return masterLanguage
     */
    public org.apache.axis.types.Language getMasterLanguage() {
        return masterLanguage;
    }


    /**
     * Sets the masterLanguage value for this TemplateBasedCommunicationChannel.
     * 
     * @param masterLanguage
     */
    public void setMasterLanguage(org.apache.axis.types.Language masterLanguage) {
        this.masterLanguage = masterLanguage;
    }


    /**
     * Gets the administrativeData value for this TemplateBasedCommunicationChannel.
     * 
     * @return administrativeData
     */
    public com.sap.xi.BASIS.RestrictedObjectAdministrativeData getAdministrativeData() {
        return administrativeData;
    }


    /**
     * Sets the administrativeData value for this TemplateBasedCommunicationChannel.
     * 
     * @param administrativeData
     */
    public void setAdministrativeData(com.sap.xi.BASIS.RestrictedObjectAdministrativeData administrativeData) {
        this.administrativeData = administrativeData;
    }


    /**
     * Gets the description value for this TemplateBasedCommunicationChannel.
     * 
     * @return description
     */
    public com.sap.xi.BASIS.Global.LONG_Description[] getDescription() {
        return description;
    }


    /**
     * Sets the description value for this TemplateBasedCommunicationChannel.
     * 
     * @param description
     */
    public void setDescription(com.sap.xi.BASIS.Global.LONG_Description[] description) {
        this.description = description;
    }

    public com.sap.xi.BASIS.Global.LONG_Description getDescription(int i) {
        return this.description[i];
    }

    public void setDescription(int i, com.sap.xi.BASIS.Global.LONG_Description _value) {
        this.description[i] = _value;
    }


    /**
     * Gets the communicationChannelID value for this TemplateBasedCommunicationChannel.
     * 
     * @return communicationChannelID
     */
    public com.sap.xi.BASIS.CommunicationChannelID getCommunicationChannelID() {
        return communicationChannelID;
    }


    /**
     * Sets the communicationChannelID value for this TemplateBasedCommunicationChannel.
     * 
     * @param communicationChannelID
     */
    public void setCommunicationChannelID(com.sap.xi.BASIS.CommunicationChannelID communicationChannelID) {
        this.communicationChannelID = communicationChannelID;
    }


    /**
     * Gets the channelTemplate value for this TemplateBasedCommunicationChannel.
     * 
     * @return channelTemplate
     */
    public com.sap.xi.BASIS.DesignObjectID getChannelTemplate() {
        return channelTemplate;
    }


    /**
     * Sets the channelTemplate value for this TemplateBasedCommunicationChannel.
     * 
     * @param channelTemplate
     */
    public void setChannelTemplate(com.sap.xi.BASIS.DesignObjectID channelTemplate) {
        this.channelTemplate = channelTemplate;
    }


    /**
     * Gets the adapterEngineName value for this TemplateBasedCommunicationChannel.
     * 
     * @return adapterEngineName
     */
    public org.apache.axis.types.Token getAdapterEngineName() {
        return adapterEngineName;
    }


    /**
     * Sets the adapterEngineName value for this TemplateBasedCommunicationChannel.
     * 
     * @param adapterEngineName
     */
    public void setAdapterEngineName(org.apache.axis.types.Token adapterEngineName) {
        this.adapterEngineName = adapterEngineName;
    }


    /**
     * Gets the adapterSpecificAttribute value for this TemplateBasedCommunicationChannel.
     * 
     * @return adapterSpecificAttribute
     */
    public com.sap.xi.BASIS.GenericProperty[] getAdapterSpecificAttribute() {
        return adapterSpecificAttribute;
    }


    /**
     * Sets the adapterSpecificAttribute value for this TemplateBasedCommunicationChannel.
     * 
     * @param adapterSpecificAttribute
     */
    public void setAdapterSpecificAttribute(com.sap.xi.BASIS.GenericProperty[] adapterSpecificAttribute) {
        this.adapterSpecificAttribute = adapterSpecificAttribute;
    }

    public com.sap.xi.BASIS.GenericProperty getAdapterSpecificAttribute(int i) {
        return this.adapterSpecificAttribute[i];
    }

    public void setAdapterSpecificAttribute(int i, com.sap.xi.BASIS.GenericProperty _value) {
        this.adapterSpecificAttribute[i] = _value;
    }


    /**
     * Gets the adapterSpecificTableAttribute value for this TemplateBasedCommunicationChannel.
     * 
     * @return adapterSpecificTableAttribute
     */
    public com.sap.xi.BASIS.GenericPropertyTable[] getAdapterSpecificTableAttribute() {
        return adapterSpecificTableAttribute;
    }


    /**
     * Sets the adapterSpecificTableAttribute value for this TemplateBasedCommunicationChannel.
     * 
     * @param adapterSpecificTableAttribute
     */
    public void setAdapterSpecificTableAttribute(com.sap.xi.BASIS.GenericPropertyTable[] adapterSpecificTableAttribute) {
        this.adapterSpecificTableAttribute = adapterSpecificTableAttribute;
    }

    public com.sap.xi.BASIS.GenericPropertyTable getAdapterSpecificTableAttribute(int i) {
        return this.adapterSpecificTableAttribute[i];
    }

    public void setAdapterSpecificTableAttribute(int i, com.sap.xi.BASIS.GenericPropertyTable _value) {
        this.adapterSpecificTableAttribute[i] = _value;
    }


    /**
     * Gets the moduleProcess value for this TemplateBasedCommunicationChannel.
     * 
     * @return moduleProcess
     */
    public com.sap.xi.BASIS.ModuleProcess getModuleProcess() {
        return moduleProcess;
    }


    /**
     * Sets the moduleProcess value for this TemplateBasedCommunicationChannel.
     * 
     * @param moduleProcess
     */
    public void setModuleProcess(com.sap.xi.BASIS.ModuleProcess moduleProcess) {
        this.moduleProcess = moduleProcess;
    }


    /**
     * Gets the senderIdentifier value for this TemplateBasedCommunicationChannel.
     * 
     * @return senderIdentifier
     */
    public com.sap.xi.BASIS.ChannelAdditionalIdentifier getSenderIdentifier() {
        return senderIdentifier;
    }


    /**
     * Sets the senderIdentifier value for this TemplateBasedCommunicationChannel.
     * 
     * @param senderIdentifier
     */
    public void setSenderIdentifier(com.sap.xi.BASIS.ChannelAdditionalIdentifier senderIdentifier) {
        this.senderIdentifier = senderIdentifier;
    }


    /**
     * Gets the receiverIdentifier value for this TemplateBasedCommunicationChannel.
     * 
     * @return receiverIdentifier
     */
    public com.sap.xi.BASIS.ChannelAdditionalIdentifier getReceiverIdentifier() {
        return receiverIdentifier;
    }


    /**
     * Sets the receiverIdentifier value for this TemplateBasedCommunicationChannel.
     * 
     * @param receiverIdentifier
     */
    public void setReceiverIdentifier(com.sap.xi.BASIS.ChannelAdditionalIdentifier receiverIdentifier) {
        this.receiverIdentifier = receiverIdentifier;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TemplateBasedCommunicationChannel)) return false;
        TemplateBasedCommunicationChannel other = (TemplateBasedCommunicationChannel) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.masterLanguage==null && other.getMasterLanguage()==null) || 
             (this.masterLanguage!=null &&
              this.masterLanguage.equals(other.getMasterLanguage()))) &&
            ((this.administrativeData==null && other.getAdministrativeData()==null) || 
             (this.administrativeData!=null &&
              this.administrativeData.equals(other.getAdministrativeData()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              java.util.Arrays.equals(this.description, other.getDescription()))) &&
            ((this.communicationChannelID==null && other.getCommunicationChannelID()==null) || 
             (this.communicationChannelID!=null &&
              this.communicationChannelID.equals(other.getCommunicationChannelID()))) &&
            ((this.channelTemplate==null && other.getChannelTemplate()==null) || 
             (this.channelTemplate!=null &&
              this.channelTemplate.equals(other.getChannelTemplate()))) &&
            ((this.adapterEngineName==null && other.getAdapterEngineName()==null) || 
             (this.adapterEngineName!=null &&
              this.adapterEngineName.equals(other.getAdapterEngineName()))) &&
            ((this.adapterSpecificAttribute==null && other.getAdapterSpecificAttribute()==null) || 
             (this.adapterSpecificAttribute!=null &&
              java.util.Arrays.equals(this.adapterSpecificAttribute, other.getAdapterSpecificAttribute()))) &&
            ((this.adapterSpecificTableAttribute==null && other.getAdapterSpecificTableAttribute()==null) || 
             (this.adapterSpecificTableAttribute!=null &&
              java.util.Arrays.equals(this.adapterSpecificTableAttribute, other.getAdapterSpecificTableAttribute()))) &&
            ((this.moduleProcess==null && other.getModuleProcess()==null) || 
             (this.moduleProcess!=null &&
              this.moduleProcess.equals(other.getModuleProcess()))) &&
            ((this.senderIdentifier==null && other.getSenderIdentifier()==null) || 
             (this.senderIdentifier!=null &&
              this.senderIdentifier.equals(other.getSenderIdentifier()))) &&
            ((this.receiverIdentifier==null && other.getReceiverIdentifier()==null) || 
             (this.receiverIdentifier!=null &&
              this.receiverIdentifier.equals(other.getReceiverIdentifier())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMasterLanguage() != null) {
            _hashCode += getMasterLanguage().hashCode();
        }
        if (getAdministrativeData() != null) {
            _hashCode += getAdministrativeData().hashCode();
        }
        if (getDescription() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDescription());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDescription(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCommunicationChannelID() != null) {
            _hashCode += getCommunicationChannelID().hashCode();
        }
        if (getChannelTemplate() != null) {
            _hashCode += getChannelTemplate().hashCode();
        }
        if (getAdapterEngineName() != null) {
            _hashCode += getAdapterEngineName().hashCode();
        }
        if (getAdapterSpecificAttribute() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAdapterSpecificAttribute());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAdapterSpecificAttribute(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAdapterSpecificTableAttribute() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAdapterSpecificTableAttribute());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAdapterSpecificTableAttribute(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getModuleProcess() != null) {
            _hashCode += getModuleProcess().hashCode();
        }
        if (getSenderIdentifier() != null) {
            _hashCode += getSenderIdentifier().hashCode();
        }
        if (getReceiverIdentifier() != null) {
            _hashCode += getReceiverIdentifier().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TemplateBasedCommunicationChannel.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://sap.com/xi/BASIS", "TemplateBasedCommunicationChannel"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("masterLanguage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MasterLanguage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "language"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("administrativeData");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AdministrativeData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://sap.com/xi/BASIS", "RestrictedObjectAdministrativeData"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://sap.com/xi/BASIS/Global", "LONG_Description"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("communicationChannelID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CommunicationChannelID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://sap.com/xi/BASIS", "CommunicationChannelID"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("channelTemplate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ChannelTemplate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://sap.com/xi/BASIS", "DesignObjectID"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("adapterEngineName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AdapterEngineName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "token"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("adapterSpecificAttribute");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AdapterSpecificAttribute"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://sap.com/xi/BASIS", "GenericProperty"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("adapterSpecificTableAttribute");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AdapterSpecificTableAttribute"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://sap.com/xi/BASIS", "GenericPropertyTable"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("moduleProcess");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ModuleProcess"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://sap.com/xi/BASIS", "ModuleProcess"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("senderIdentifier");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SenderIdentifier"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://sap.com/xi/BASIS", "ChannelAdditionalIdentifier"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("receiverIdentifier");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ReceiverIdentifier"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://sap.com/xi/BASIS", "ChannelAdditionalIdentifier"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
