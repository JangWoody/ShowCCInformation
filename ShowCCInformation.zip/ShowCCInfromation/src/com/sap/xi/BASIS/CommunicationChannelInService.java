/**
 * CommunicationChannelInService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.sap.xi.BASIS;

public interface CommunicationChannelInService extends javax.xml.rpc.Service {
    public java.lang.String getCommunicationChannelInPortAddress();

    public com.sap.xi.BASIS.CommunicationChannelIn getCommunicationChannelInPort() throws javax.xml.rpc.ServiceException;

    public com.sap.xi.BASIS.CommunicationChannelIn getCommunicationChannelInPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
