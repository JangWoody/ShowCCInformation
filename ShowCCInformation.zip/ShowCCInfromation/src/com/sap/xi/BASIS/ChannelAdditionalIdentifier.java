/**
 * ChannelAdditionalIdentifier.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.sap.xi.BASIS;

public class ChannelAdditionalIdentifier  implements java.io.Serializable, org.apache.axis.encoding.SimpleType {
    private org.apache.axis.types.Token _value;

    private org.apache.axis.types.Token schemeID;  // attribute

    private org.apache.axis.types.Token schemeAgencyID;  // attribute

    public ChannelAdditionalIdentifier() {
    }

    // Simple Types must have a String constructor
    public ChannelAdditionalIdentifier(org.apache.axis.types.Token _value) {
        this._value = _value;
    }
    public ChannelAdditionalIdentifier(java.lang.String _value) {
        this._value = new org.apache.axis.types.Token(_value);
    }

    // Simple Types must have a toString for serializing the value
    public java.lang.String toString() {
        return _value == null ? null : _value.toString();
    }


    /**
     * Gets the _value value for this ChannelAdditionalIdentifier.
     * 
     * @return _value
     */
    public org.apache.axis.types.Token get_value() {
        return _value;
    }


    /**
     * Sets the _value value for this ChannelAdditionalIdentifier.
     * 
     * @param _value
     */
    public void set_value(org.apache.axis.types.Token _value) {
        this._value = _value;
    }


    /**
     * Gets the schemeID value for this ChannelAdditionalIdentifier.
     * 
     * @return schemeID
     */
    public org.apache.axis.types.Token getSchemeID() {
        return schemeID;
    }


    /**
     * Sets the schemeID value for this ChannelAdditionalIdentifier.
     * 
     * @param schemeID
     */
    public void setSchemeID(org.apache.axis.types.Token schemeID) {
        this.schemeID = schemeID;
    }


    /**
     * Gets the schemeAgencyID value for this ChannelAdditionalIdentifier.
     * 
     * @return schemeAgencyID
     */
    public org.apache.axis.types.Token getSchemeAgencyID() {
        return schemeAgencyID;
    }


    /**
     * Sets the schemeAgencyID value for this ChannelAdditionalIdentifier.
     * 
     * @param schemeAgencyID
     */
    public void setSchemeAgencyID(org.apache.axis.types.Token schemeAgencyID) {
        this.schemeAgencyID = schemeAgencyID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ChannelAdditionalIdentifier)) return false;
        ChannelAdditionalIdentifier other = (ChannelAdditionalIdentifier) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this._value==null && other.get_value()==null) || 
             (this._value!=null &&
              this._value.equals(other.get_value()))) &&
            ((this.schemeID==null && other.getSchemeID()==null) || 
             (this.schemeID!=null &&
              this.schemeID.equals(other.getSchemeID()))) &&
            ((this.schemeAgencyID==null && other.getSchemeAgencyID()==null) || 
             (this.schemeAgencyID!=null &&
              this.schemeAgencyID.equals(other.getSchemeAgencyID())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (get_value() != null) {
            _hashCode += get_value().hashCode();
        }
        if (getSchemeID() != null) {
            _hashCode += getSchemeID().hashCode();
        }
        if (getSchemeAgencyID() != null) {
            _hashCode += getSchemeAgencyID().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ChannelAdditionalIdentifier.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://sap.com/xi/BASIS", "ChannelAdditionalIdentifier"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("schemeID");
        attrField.setXmlName(new javax.xml.namespace.QName("", "schemeID"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://sap.com/xi/BASIS", ">ChannelAdditionalIdentifier>schemeID"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("schemeAgencyID");
        attrField.setXmlName(new javax.xml.namespace.QName("", "schemeAgencyID"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://sap.com/xi/BASIS", ">ChannelAdditionalIdentifier>schemeAgencyID"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_value");
        elemField.setXmlName(new javax.xml.namespace.QName("", "_value"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "token"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.SimpleSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.SimpleDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
